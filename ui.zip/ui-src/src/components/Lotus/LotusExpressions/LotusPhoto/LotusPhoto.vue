
<template>
    
    <div class="lotusPhoto">
        &nbsp;
    </div>
</template>
