<template>
    <div class="lotusFooter">
        <div class="lotusFooter__content">
            <slot name="lotus"></slot>
            <slot name="lotusStory"></slot>
            <slot name="lotusShortform"></slot>
            <slot name="lotusBullet"></slot>
            <slot name="lotusPhoto"></slot>
            <slot name="lotusEvents"></slot>
            <slot name="lotusMusic"></slot>

        </div>
    </div>
</template>

<script>
    export default {

    }
</script>
