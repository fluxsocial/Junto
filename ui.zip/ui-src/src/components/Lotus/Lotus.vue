<template>
    <div class="lotus">
        <div class="lotus__content">
            <router-link to="/lotus" class="lotus__icon">
                <slot name="lotusIcon"></slot>
            </router-link>

        </div>
    </div>

</template>
