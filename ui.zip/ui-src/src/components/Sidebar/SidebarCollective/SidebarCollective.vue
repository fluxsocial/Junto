<template>
    <section class="sidebar">
        <p class="sidebar__header">SPHERES</p>
        <p class="sidebar__border">&nbsp;</p>
        <div class="sidebar__spheres">
            <div class="sidebar__sphere">
                <p class="sidebar__sphere--active">&nbsp;</p>
                <p class="sidebar__sphere--text">collective</p>
            </div>

            <div class="sidebar__sphere">
                <!-- <p class="sidebar__sphere--active">&nbsp;</p> -->
                <p class="sidebar__sphere--text">following</p>
            </div>
        </div>
    </section>
</template>
