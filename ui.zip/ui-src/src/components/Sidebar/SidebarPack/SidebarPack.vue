<template>
    <section class="sidebar">
        <p class="sidebar__header">PACKS</p>
        <p class="sidebar__border">&nbsp;</p>
        <div class="sidebar__packs">
            <div class="sidebar__pack">
                <p class="sidebar__pack--active">&nbsp;</p>
                <img src="./../../../assets/img/junto-web__eric.png" alt="" class="sidebar__pack--profile">
                <p class="sidebar__pack--name">Gnarly Nomads</p>
            </div>

            <div class="sidebar__sphere">
                <img src="./../../../assets/img/junto-web__eric.png" alt="" class="sidebar__pack--profile">
                <p class="sidebar__sphere--text">Mees Tomatoes</p>
            </div>
        </div>
    </section>
</template>
